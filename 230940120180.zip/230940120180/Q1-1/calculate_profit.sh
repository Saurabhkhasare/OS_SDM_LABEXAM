#!/bin/bash

# Prompt user for sales and cost
read -p "Enter Sales: " sales
read -p "Enter Cost: " cost

# Calculate profit
profit=$((sales - cost))

# Subtract 10% as taxes
taxes=$((profit * 10 / 100))

# Calculate net profit
net_profit=$((profit - taxes))

# Display the result
echo "Profit: $profit"
echo "Taxes (10%): $taxes"
echo "Net Profit: $net_profit"

